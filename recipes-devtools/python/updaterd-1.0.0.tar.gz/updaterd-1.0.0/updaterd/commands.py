from abc import ABC, abstractmethod
from datetime import datetime
from database import UpdaterdDB
import sys

db = UpdaterdDB("pacman.db")


class Command(ABC):
    @abstractmethod
    def execute(self, data):
        pass


class CreateHistoryTableCommand(Command):
    def execute(self, data=None):
        db.create_table(
            "history",
            {
                "id": "integer primary key autoincrement",
                "name": "text not null",
                "date": "text not null",
                "category": "text not null",
                "result": "bool not null",
            },
        )


class InstallCommand(Command):
    """AI is creating summary for"""

    def execute(self, data):
        """AI is creating summary for execute

        Args:
            data ([type]): [description]
        """
        data["date"] = datetime.utcnow().isoformat()
        db.add("history", data)
        return


class UnInstallCommand(Command):
    """AI is creating summary for"""

    def execute(self, data):
        pass


class PackageCommand(Command):
    """AI is creating summary for"""

    def execute(self, data):
        pass


class PackageInfoCommand(Command):
    """AI is creating summary for"""

    def execute(self, data):
        pass


class HistoryCommand(Command):
    """AI is creating summary for"""

    def __init__(self, order_by="date"):
        self.order_by = order_by

    def execute(self):
        """AI is creating summary for execute

        Returns:
            [type]: [description]
        """
        return db.select("history", order_by=self.order_by).fetchall()


class DeleteCommand(Command):
    def execute(self, data):
        """AI is creating summary for execute

        Args:
            data ([type]): [description]
        """
        db.delete("history", {"id": data})
        return


class QuitCommand(Command):
    def execute(self, data=None):
        """AI is creating summary for execute"""
        sys.exit()
