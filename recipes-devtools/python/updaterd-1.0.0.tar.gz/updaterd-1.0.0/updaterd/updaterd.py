import pkg_resources
import os
from gi.repository import GLib
from pydbus import SessionBus
import commands
import rauc_commands

loop = GLib.MainLoop()


class UpdaterDBUSService(object):

    """AI is creating summary for

    Returns:
            [type]: [description]
    """

    def __init__(self):
        # Load dbus xml
        dbus = pkg_resources.resource_string(__name__, "dbus.xml").decode("utf-8")

    def Install(self, name):
        """
        returns the string 'Hello, World!'
        """
        data = {"pkgname": name}
        rauc_commands.RaucInstallFwCommand().execute(data)
        return "Hello, World!" + name

    def UnInstall(self, result):
        return "UnInstall"

    def Package(self, result):
        return "Package"

    def Encrypt(self, result):
        return "Encrypt"

    def Completed(self, result):
        """returns the string 'Hello, World!'"""
        data = {
            "name": name,
            "category": "Update",
            "result": True if result == 0 else False,
        }
        commands.InstallCommand.execute("history", data)
        return "Hello, World!"

    def Quit(self):
        """removes this object from the DBUS connection and exits"""
        loop.quit()


def run():
    bus = SessionBus()
    try:
        bus.publish("com.test.Updaterd", UpdaterDBUSService())
        loop.run()
    except RuntimeError:
        print("Error: Failed to create server")


if __name__ == "__main__":
    run()
