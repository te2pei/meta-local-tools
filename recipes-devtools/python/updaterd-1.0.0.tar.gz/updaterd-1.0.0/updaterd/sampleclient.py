#!/usr/bin/env python3

import sys
from pydbus import SessionBus
from gi.repository import GLib


def main():

    bus = SessionBus()
    pm = bus.get("com.test.Updaterd")
    bus.subscribe(object="/com/test/updaterd", signal_fired=Installed)

    if sys.argv[1:] == ["--exit-service"]:
        pm.Exit()
    else:

        reply = pm.Install("test 123")
        print(reply)

        print(pm.Status)

        print(pm.Progress)

        print("Version" + pm.Version)

        for key in pm.PackageList:
            print("[PkgList]" + key + " = " + pm.PackageList[key])

        for key in pm.PackageInfo:
            print("[PkgInfo]" + key + " = " + pm.PackageInfo[key])

        for key in pm.History:
            print("[History]" + key + " = " + pm.History[key])


#        pm.Exit()


def Installed(*args):
    """
    Callback on emitting signal from server
    """
    print("**** Package Installed ****")
    print("result = " + str(args[4][0]))
    print(args[4][1])


if __name__ == "__main__":

    loop = GLib.MainLoop()
    try:
        main()
        loop.run()
    except:
        loop.quit()
