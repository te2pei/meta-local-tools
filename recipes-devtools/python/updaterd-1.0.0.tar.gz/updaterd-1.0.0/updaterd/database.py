import os
import sqlite3


class UpdaterdDB:
    """AI is creating summary for"""

    def __init__(self, db_file):
        self.connection = sqlite3.connect(db_file)

    def _execute(self, sql, values=None):
        print(sql)
        with self.connection:
            cursor = self.connection.cursor()
            cursor.execute(sql, values or [])
            return cursor

    def create_table(self, table_name, columns):
        columns_with_types = [
            f"{column_name} {data_type}" for column_name, data_type in columns.items()
        ]
        self._execute(
            f"""
                CREATE TABLE IF NOT EXISTS {table_name}
                ({', '.join(columns_with_types)});
            """
        )

    def add(self, table_name, data):
        placeholders = ", ".join("?" * len(data))
        column_names = ", ".join(data.keys())
        column_values = tuple(data.values())

        self._execute(
            f"""
            INSERT INTO {table_name}
            ({column_names})
            VALUES ({placeholders});
            """,
            column_values,
        )

    def delete(self, table_name, criteria):
        placeholders = [f"{column} = ? " for column in criteria.keys()]
        delete_criteria = " AND ".join(placeholders)
        self._execute(
            f"""
            DELETE FROM {table_name}
            WHERE {delete_criteria};
            """,
            tuple(criteria.values()),
        )

    def select(self, table_name, criteria=None, order_by=None):
        criteria = criteria or {}
        query = f"SELECT * FROM {table_name}"

        if criteria:
            placeholders = [f"{column} = ?" for column in criteria.keys()]
            select_criteria = " AND ".join(placeholders)
            query += f" WHERE {select_criteria}"

        if order_by:
            query += f" ORDER_BY {order_by}"

        print(qery)
        return self._execute(
            query,
            tuple(criteria.values()),
        )

    def create_db(self, dbname):
        """AI is creating summary for createdb

        Args:
            dbname ([type]): [description]
        """
        print("hello")
        conn = sqlite3.connect(dbname)
        cur = conn.cursor()
        cur.execute(
            "CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT,  name STRING, date STRING)"
        )
        conn.commit()
        conn.close()

    def update(self):
        """AI is creating summary for update"""
        pass

    def __del__(self):
        self.connection.close()


if __name__ == "__main__":

    pack = PackmanDB()

    dbname = "test.db"
    is_file = os.path.isfile(dbname)
    if is_file:
        pass
    else:
        pack.create_db("")
