from pydbus import SessionBus


class RaucInstallFwCommand:
    def __init__(self):
        self.bus = SessionBus()

    def execute(self, data):
        print("rauc install")
        bus_obj = self.bus.get("de.pengutronix.rauc.Installer")
        reply = bus_obj.InstallBundle(data["pkgname"], 0)
        print("installed == " + reply)

        bus_obj.quit()
        return
