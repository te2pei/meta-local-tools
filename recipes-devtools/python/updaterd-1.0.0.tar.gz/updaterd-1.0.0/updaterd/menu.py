import commands
from collections import OrderedDict

if __name__ == "__main__":
    commands.CreateHistoryTableCommand().execute()


class Option:
    def __init__(self, name, command, prep_call=None):
        self.name = name
        self.command = command
        self.prep_call = prep_call

    def _hanndle_message(self, message):
        if isinstance(message, list):
            print_pacman(message)
        else:
            print(message)

    def choose(self):
        data = self.prep_call() if self.prep_call else None
        message = self.command.execute(data) if data else self.command.execute()
        self._hanndle_message(message)

    def __str__(self):
        return self.name


def get_github_import_options():
    return {
        "github_username": get_user_input(""),
        "preserve_timestamps": get_user_input("タイムスタンプを維持しますか[Y/n]", required=False)
        in {"Y", "y", None},
    }


def print_options(options):
    for shortcut, option in options.items():
        print(f"({shortcut} {option})")


def option_choice_is_valid(choice, options):
    return choice in options or choice.upper() in options


def get_option_choice(options):
    choice = input("Please input: ")
    while not option_choice_is_valid(choice, options):
        print("")
        choice = input("Please input: ")
    return options[choice.upper()]


def get_user_input(label, required=True):
    value = input(f"{label}: ") or None
    while required and not value:
        value = input(f"{label}: ") or None
    return value


if __name__ == "__main__":

    options = OrderedDict(
        {
            "H": Option("History", commands.HistoryCommand(), prep_call=None),
            "I": Option("Install", commands.InstallCommand(), prep_call=None),
            "L": Option("ListBookmark", commands.InstallCommand(), prep_call=None),
            "Q": Option("Quit", commands.QuitCommand(), prep_call=None),
        }
    )

    print_options(options)

    chosen_option = get_option_choice(options)
    chosen_option.choose()
