# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['updaterd']

package_data = \
{'': ['*']}

install_requires = \
['Sphinx>=5.0.2,<6.0.0',
 'black>=22.6.0,<23.0.0',
 'pylint>=2.14.4,<3.0.0',
 'pytest-cov>=3.0.0,<4.0.0',
 'pytest>=7.1.2,<8.0.0',
 'radon>=5.1.0,<6.0.0',
 'sphinx-rtd-theme>=1.0.0,<2.0.0']

setup_kwargs = {
    'name': 'updaterd',
    'version': '1.0.0',
    'description': 'updaterd project',
    'long_description': None,
    'author': 'taro hanako',
    'author_email': 'taro@xxxx.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
